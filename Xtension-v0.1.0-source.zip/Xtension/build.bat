@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "ARCH=%~1"
if "%ARCH%"=="" set "ARCH=x64"
if /i not "%ARCH%"=="x64" if /i not "%ARCH%"=="x86" (
  echo ERROR: Unsupported architecture "%ARCH%". Use: build.bat x86 ^| x64
  if not defined CI pause
  exit /b 2
)
set "ARCH=%ARCH:~0,3%"
if /i "%ARCH%"=="x64" (
  set "FRAMEWORK=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319"
) else (
  set "FRAMEWORK=%WINDIR%\Microsoft.NET\Framework\v4.0.30319"
)
set "CSC=%FRAMEWORK%\csc.exe"
set "UIADIR=%FRAMEWORK%\WPF"
if not exist "!UIADIR!\UIAutomationClient.dll" set "UIADIR=%FRAMEWORK%"
set "WINDOWSBASE=%FRAMEWORK%\WindowsBase.dll"
if not exist "!WINDOWSBASE!" set "WINDOWSBASE=!UIADIR!\WindowsBase.dll"
set "OUTDIR=%~dp0dist"
set "OUTPUT=!OUTDIR!\Xtension-win-%ARCH%.exe"
set "SOURCES="

if not exist "!CSC!" (
  echo ERROR: .NET Framework C# compiler not found: !CSC!
  echo Install Visual Studio Build Tools or the .NET Framework Developer Pack.
  if not defined CI pause
  exit /b 1
)
if not exist "!UIADIR!\UIAutomationClient.dll" (
  echo ERROR: UIAutomationClient.dll not found under !UIADIR!
  if not defined CI pause
  exit /b 1
)
if not exist "!UIADIR!\UIAutomationTypes.dll" (
  echo ERROR: UIAutomationTypes.dll not found under !UIADIR!
  if not defined CI pause
  exit /b 1
)
if not exist "!WINDOWSBASE!" (
  echo ERROR: WindowsBase.dll not found.
  if not defined CI pause
  exit /b 1
)
if not exist "%~dp0app.manifest" (
  echo ERROR: app.manifest is missing.
  if not defined CI pause
  exit /b 1
)
if not exist "%~dp0src\AppInfo.cs" (
  echo ERROR: src\AppInfo.cs is missing.
  if not defined CI pause
  exit /b 1
)

if not exist "!OUTDIR!" mkdir "!OUTDIR!"
if exist "!OUTPUT!" del /q "!OUTPUT!"
for %%F in ("%~dp0src\*.cs") do if exist "%%~fF" set "SOURCES=!SOURCES! "%%~fF""
if not defined SOURCES (
  echo ERROR: No C# source files found under src\.
  if not defined CI pause
  exit /b 1
)

echo Building Xtension v0.1.0 for Windows !ARCH!...
"!CSC!" /nologo /codepage:65001 /target:winexe /optimize+ /platform:!ARCH! /win32manifest:"%~dp0app.manifest" /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Core.dll /r:"!WINDOWSBASE!" /r:"!UIADIR!\UIAutomationClient.dll" /r:"!UIADIR!\UIAutomationTypes.dll" /out:"!OUTPUT!" !SOURCES!
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Any previous output for this architecture was removed.
  if not defined CI pause
  exit /b 1
)
if not exist "!OUTPUT!" (
  echo ERROR: Compiler returned success, but output is missing.
  if not defined CI pause
  exit /b 1
)
for %%F in ("!OUTPUT!") do echo BUILD SUCCEEDED: %%~fF ^(%%~zF bytes^)
echo Run this EXE on Windows with Brave. No administrator rights are requested.
if not defined CI pause
exit /b 0
