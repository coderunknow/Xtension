@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo Xtension v0.1.0 - GitHub publish helper
echo This script pushes main and tag v0.1.0. It never force-pushes or overwrites an existing tag.
echo.
where git >nul 2>nul
if errorlevel 1 (
  echo ERROR: Git is not installed or not available on PATH.
  exit /b 1
)
if not exist ".git" (
  echo ERROR: This folder is not a Git clone.
  echo First clone https://github.com/coderunknow/Xtension.git, copy the extracted source files into that clone, then run this script there.
  exit /b 1
)
set "ORIGIN="
for /f "usebackq delims=" %%U in (`git remote get-url origin 2^>nul`) do set "ORIGIN=%%U"
if /i not "%ORIGIN%"=="https://github.com/coderunknow/Xtension.git" if /i not "%ORIGIN%"=="git@github.com:coderunknow/Xtension.git" (
  echo ERROR: origin is not coderunknow/Xtension.
  echo Current origin: %ORIGIN%
  exit /b 1
)
set "BRANCH="
for /f "usebackq delims=" %%B in (`git branch --show-current`) do set "BRANCH=%%B"
if not "%BRANCH%"=="main" (
  echo ERROR: Switch to main before publishing. Current branch: %BRANCH%
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0verify-source.ps1"
if errorlevel 1 (
  echo ERROR: Source consistency check failed; nothing was pushed.
  exit /b 1
)
git diff --check
if errorlevel 1 (
  echo ERROR: git diff --check reported whitespace errors; nothing was pushed.
  exit /b 1
)

git fetch origin
if errorlevel 1 (
  echo ERROR: Could not fetch origin. Check network and GitHub authentication.
  exit /b 1
)

rem Do not publish if the requested release tag already exists on the remote or locally.
set "REMOTE_TAG="
for /f "tokens=2" %%S in ('git ls-remote --tags origin refs/tags/v0.1.0') do set "REMOTE_TAG=%%S"
if defined REMOTE_TAG (
  echo ERROR: Remote tag v0.1.0 already exists; refusing to overwrite or retag it.
  exit /b 2
)
git rev-parse --verify refs/tags/v0.1.0 >nul 2>nul
if not errorlevel 1 (
  echo ERROR: Local tag v0.1.0 already exists; inspect it manually before continuing.
  exit /b 2
)

git add -A
git diff --cached --check
if errorlevel 1 (
  echo ERROR: Staged diff check failed.
  exit /b 1
)
git diff --cached --quiet
if errorlevel 1 (
  git commit -m "release: publish Xtension v0.1.0"
  if errorlevel 1 (
    echo ERROR: Commit failed. Verify git user.name and user.email.
    exit /b 1
  )
) else (
  echo No file changes to commit; will tag the current main commit after pushing.
)

git push origin main
if errorlevel 1 (
  echo ERROR: Push to main failed. The release tag has not been created.
  exit /b 1
)
git tag -a v0.1.0 -m "Xtension v0.1.0"
if errorlevel 1 (
  echo ERROR: Could not create tag v0.1.0. Main was pushed; inspect local and remote tags before retrying.
  exit /b 1
)
git push origin refs/tags/v0.1.0
if errorlevel 1 (
  echo ERROR: Main was pushed but the tag push failed. Do not create a replacement tag blindly.
  exit /b 1
)
echo.
echo SUCCESS: main and tag v0.1.0 were pushed.
echo GitHub Actions should now build Windows x86/x64 and publish a release if CI passes.
echo Check https://github.com/coderunknow/Xtension/actions and https://github.com/coderunknow/Xtension/releases
exit /b 0
