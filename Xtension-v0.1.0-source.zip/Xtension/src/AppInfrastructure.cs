using System;
using System.Drawing;
using System.IO;
using Microsoft.Win32;
using System.Windows.Forms;

namespace Xtension
{
    internal static class AppPaths
    {
        public static readonly string DirectoryPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), AppInfo.ProductName);
        public static readonly string LogFile = Path.Combine(DirectoryPath, "app.log");
        public static void EnsureDirectory()
        {
            if (!Directory.Exists(DirectoryPath)) Directory.CreateDirectory(DirectoryPath);
        }
    }


    internal static class StartupManager
    {
        private const string RunKeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
        private const string ValueName = AppInfo.ProductName;

        public static bool IsEnabled()
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(RunKeyPath, false))
                {
                    if (key == null) return false;
                    string value = key.GetValue(ValueName) as string;
                    return !String.IsNullOrWhiteSpace(value);
                }
            }
            catch { return false; }
        }

        public static void SetEnabled(bool enabled)
        {
            using (RegistryKey key = Registry.CurrentUser.CreateSubKey(RunKeyPath))
            {
                if (key == null) throw new InvalidOperationException("Could not open the current-user Run registry key.");
                if (enabled)
                {
                    string exe = Application.ExecutablePath;
                    key.SetValue(ValueName, "\"" + exe + "\"", RegistryValueKind.String);
                }
                else
                {
                    key.DeleteValue(ValueName, false);
                }
            }
        }
    }


    internal static class TrayIconFactory
    {
        public static Icon CreateIcon()
        {
            using (Bitmap bitmap = new Bitmap(32, 32))
            using (Graphics graphics = Graphics.FromImage(bitmap))
            {
                graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                graphics.Clear(Color.Transparent);
                using (SolidBrush bg = new SolidBrush(Color.FromArgb(37, 99, 235)))
                    graphics.FillRoundedRectangle(bg, new Rectangle(1, 1, 30, 30), 7);
                using (Pen pen = new Pen(Color.White, 3.0f))
                {
                    pen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                    pen.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                    graphics.DrawLine(pen, 10, 10, 22, 22);
                    graphics.DrawLine(pen, 22, 10, 10, 22);
                }
                IntPtr handle = bitmap.GetHicon();
                try
                {
                    Icon temporary = Icon.FromHandle(handle);
                    return (Icon)temporary.Clone();
                }
                finally { NativeMethods.DestroyIcon(handle); }
            }
        }
    }


    internal static class GraphicsExtensions
    {
        public static void FillRoundedRectangle(this Graphics graphics, Brush brush, Rectangle bounds, int radius)
        {
            int diameter = radius * 2;
            using (System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath())
            {
                path.AddArc(bounds.Left, bounds.Top, diameter, diameter, 180, 90);
                path.AddArc(bounds.Right - diameter, bounds.Top, diameter, diameter, 270, 90);
                path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
                path.AddArc(bounds.Left, bounds.Bottom - diameter, diameter, diameter, 90, 90);
                path.CloseFigure();
                graphics.FillPath(brush, path);
            }
        }
    }


    internal static class ApplicationContextHolder
    {
        public static TrayAppContext Context;
    }

}
