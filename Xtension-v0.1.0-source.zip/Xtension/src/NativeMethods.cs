using System;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Xtension
{
    internal static class NativeMethods
    {
        public const int WS_EX_TOOLWINDOW = 0x00000080;
        public const int WS_EX_NOACTIVATE = 0x08000000;
        public const int WM_MOUSEACTIVATE = 0x0021;
        public const int MA_NOACTIVATE = 3;
        private const uint GA_ROOT = 2;
        private const uint INPUT_KEYBOARD = 1;
        private const uint KEYEVENTF_KEYUP = 0x0002;
        private const ushort VK_CONTROL = 0x11;
        private const ushort VK_W = 0x57;

        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")]
        private static extern IntPtr GetAncestor(IntPtr hwnd, uint flags);
        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint processId);
        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern int GetWindowText(IntPtr hwnd, StringBuilder text, int maxCount);
        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetWindowRect(IntPtr hwnd, out RECT rect);
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool IsIconic(IntPtr hwnd);
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool IsWindowVisible(IntPtr hwnd);
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool IsWindow(IntPtr hwnd);
        [DllImport("user32.dll", EntryPoint = "SetProcessDpiAwarenessContext", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetProcessDpiAwarenessContext(IntPtr value);
        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetProcessDPIAware();
        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool DestroyIcon(IntPtr hIcon);

        public static void EnableBestDpiAwareness()
        {
            // Prefer Per-Monitor-V2 on supported Windows 10+ releases.
            // Keep a fallback for older Windows versions.
            try
            {
                if (SetProcessDpiAwarenessContext(new IntPtr(-4))) return;
            }
            catch (EntryPointNotFoundException) { }
            catch (DllNotFoundException) { }
            try { SetProcessDPIAware(); } catch { }
        }
        [DllImport("user32.dll", SetLastError = true)]
        private static extern uint SendInput(uint numberOfInputs, INPUT[] inputs, int sizeOfInput);

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        // Win32 INPUT contains a union whose size is determined by MOUSEINPUT
        // on both x86 and x64. Declaring only KEYBDINPUT makes INPUT too small
        // on x64 (typically 32 bytes instead of the required 40), causing
        // SendInput to fail with ERROR_INVALID_PARAMETER.
        [StructLayout(LayoutKind.Sequential)]
        private struct INPUT
        {
            public uint type;
            public INPUTUNION U;
        }

        [StructLayout(LayoutKind.Explicit)]
        private struct INPUTUNION
        {
            [FieldOffset(0)] public MOUSEINPUT mi;
            [FieldOffset(0)] public KEYBDINPUT ki;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct MOUSEINPUT
        {
            public int dx;
            public int dy;
            public uint mouseData;
            public uint dwFlags;
            public uint time;
            public UIntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct KEYBDINPUT
        {
            public ushort wVk;
            public ushort wScan;
            public uint dwFlags;
            public uint time;
            public UIntPtr dwExtraInfo;
        }

        public static IntPtr GetForegroundRootWindow()
        {
            IntPtr fg = GetForegroundWindow();
            if (fg == IntPtr.Zero) return IntPtr.Zero;
            IntPtr root = GetAncestor(fg, GA_ROOT);
            return root == IntPtr.Zero ? fg : root;
        }

        public static bool IsBraveWindow(IntPtr hwnd)
        {
            if (hwnd == IntPtr.Zero) return false;
            uint pid;
            GetWindowThreadProcessId(hwnd, out pid);
            if (pid == 0) return false;
            try
            {
                using (Process p = Process.GetProcessById((int)pid))
                    return String.Equals(p.ProcessName, "brave", StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }

        public static Rectangle GetWindowBounds(IntPtr hwnd)
        {
            RECT r;
            if (!GetWindowRect(hwnd, out r)) return Rectangle.Empty;
            return Rectangle.FromLTRB(r.Left, r.Top, r.Right, r.Bottom);
        }

        public static string GetWindowTitle(IntPtr hwnd)
        {
            StringBuilder sb = new StringBuilder(512);
            try { GetWindowText(hwnd, sb, sb.Capacity); } catch { }
            return sb.ToString();
        }

        public static int GetInputStructureSize()
        {
            return Marshal.SizeOf(typeof(INPUT));
        }

        public static bool SendCtrlW(out string failure)
        {
            failure = null;
            INPUT[] inputs = new INPUT[4];
            inputs[0] = KeyInput(VK_CONTROL, false);
            inputs[1] = KeyInput(VK_W, false);
            inputs[2] = KeyInput(VK_W, true);
            inputs[3] = KeyInput(VK_CONTROL, true);

            int inputSize = Marshal.SizeOf(typeof(INPUT));
            uint sent = SendInput((uint)inputs.Length, inputs, inputSize);
            if (sent == inputs.Length) return true;

            int error = Marshal.GetLastWin32Error();
            failure = String.Format(
                "SendInput sent {0}/{1} keyboard events (INPUT size={2}; Win32 error={3}: {4}).",
                sent, inputs.Length, inputSize, error, new System.ComponentModel.Win32Exception(error).Message);

            // In case Windows accepted only a partial sequence, try to release
            // both keys so Ctrl is not left logically pressed.
            INPUT[] releases = new INPUT[]
            {
                KeyInput(VK_W, true),
                KeyInput(VK_CONTROL, true)
            };
            SendInput((uint)releases.Length, releases, Marshal.SizeOf(typeof(INPUT)));
            return false;
        }

        private static INPUT KeyInput(ushort key, bool keyUp)
        {
            INPUT input = new INPUT();
            input.type = INPUT_KEYBOARD;
            input.U.ki.wVk = key;
            input.U.ki.wScan = 0;
            input.U.ki.dwFlags = keyUp ? KEYEVENTF_KEYUP : 0;
            input.U.ki.time = 0;
            input.U.ki.dwExtraInfo = UIntPtr.Zero;
            return input;
        }
    }

}
