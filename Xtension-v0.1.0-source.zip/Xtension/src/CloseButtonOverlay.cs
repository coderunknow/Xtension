using System;
using System.Drawing;
using System.Windows.Forms;

namespace Xtension
{
    internal sealed class CloseButtonOverlay : Form
    {
        private bool _hover;
        private bool _pressed;
        private bool _armed;
        private readonly Color _keyColor = Color.Magenta;
        private readonly ToolTip _toolTip;

        public CloseButtonOverlay()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            TopMost = true;
            BackColor = _keyColor;
            TransparencyKey = _keyColor;
            Size = new Size(26, 26);
            DoubleBuffered = true;
            Cursor = Cursors.Hand;
            _toolTip = new ToolTip { InitialDelay = 450, ReshowDelay = 150, AutoPopDelay = 5000, ShowAlways = true };
            _toolTip.SetToolTip(this, "Đóng tab Brave đang được chọn (nhấp một lần)");
            AccessibleName = "Đóng tab Brave đang được chọn";
            AccessibleDescription = "Chỉ đóng tab đã được xác nhận là tab đang hoạt động.";
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= NativeMethods.WS_EX_NOACTIVATE | NativeMethods.WS_EX_TOOLWINDOW;
                return cp;
            }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == NativeMethods.WM_MOUSEACTIVATE)
            {
                m.Result = new IntPtr(NativeMethods.MA_NOACTIVATE);
                return;
            }
            base.WndProc(ref m);
        }

        public void SetTarget(Rectangle bounds)
        {
            if (bounds == Rectangle.Empty) { Hide(); return; }
            Bounds = bounds;
            if (!Visible) Show();
            TopMost = true;
            Invalidate();
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            _hover = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            _hover = false;
            _pressed = false;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            _armed = e.Button == MouseButtons.Left && e.X >= 0 && e.Y >= 0 && e.X < Width && e.Y < Height;
            _pressed = _armed;
            Invalidate();
            base.OnMouseDown(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            bool invoke = _armed && e.Button == MouseButtons.Left && e.X >= 0 && e.Y >= 0 && e.X < Width && e.Y < Height;
            _armed = false;
            _pressed = false;
            Invalidate();
            if (invoke)
            {
                // The actual close is validated against a fresh UI Automation scan.
                TrayAppContext context = ApplicationContextHolder.Context;
                if (context != null) context.TryCloseActiveTab();
            }
            base.OnMouseUp(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Rectangle circle = new Rectangle(1, 1, Width - 3, Height - 3);
            Color fill = _pressed ? Color.FromArgb(153, 27, 27) : (_hover ? Color.FromArgb(220, 70, 75) : Color.FromArgb(38, 45, 57));
            using (SolidBrush brush = new SolidBrush(fill)) e.Graphics.FillEllipse(brush, circle);
            using (Pen border = new Pen(_hover ? Color.FromArgb(255, 170, 170) : Color.FromArgb(210, 216, 225), 1f))
                e.Graphics.DrawEllipse(border, circle);
            using (Pen xpen = new Pen(Color.White, _hover ? 2.25f : 2f))
            {
                xpen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                xpen.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                e.Graphics.DrawLine(xpen, 8, 8, Width - 8, Height - 8);
                e.Graphics.DrawLine(xpen, Width - 8, 8, 8, Height - 8);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && _toolTip != null) _toolTip.Dispose();
            base.Dispose(disposing);
        }
    }

}
