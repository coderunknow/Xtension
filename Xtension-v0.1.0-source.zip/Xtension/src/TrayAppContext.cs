using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using Microsoft.Win32;
using System.Windows.Forms;

namespace Xtension
{
    internal sealed class TrayAppContext : ApplicationContext
    {
        private readonly NotifyIcon _tray;
        private readonly System.Windows.Forms.Timer _timer;
        private readonly CloseButtonOverlay _overlay;
        private readonly MainForm _mainForm;
        private ToolStripMenuItem _toggleMenuItem;
        private ToolStripMenuItem _startupMenuItem;
        private DiagnosticsForm _diagnostics;
        private bool _enabled = true;
        private bool _isExiting;
        private bool _closeBalloonShown;
        private IntPtr _lastWindow;
        private IntPtr _lastBraveWindow;
        private Rectangle _lastBounds = Rectangle.Empty;
        private string _lastTabName = String.Empty;
        private DateTime _lastErrorLog = DateTime.MinValue;
        private DateTime _lastCloseAttempt = DateTime.MinValue;

        public ScanResult LastResult { get; private set; }
        public bool OverlayEnabled { get { return _enabled; } }
        public bool OverlayVisible { get { return _overlay != null && _overlay.Visible; } }
        public string LogPath { get { return AppPaths.LogFile; } }
        public bool IsExiting { get { return _isExiting; } }

        public TrayAppContext()
        {
            ApplicationContextHolder.Context = this;
            LastResult = new ScanResult();
            LastResult.Status = "Đang khởi động. Mở Brave để nhận diện tab đang chọn.";
            _overlay = new CloseButtonOverlay();
            _mainForm = new MainForm(this);

            ContextMenuStrip menu = new ContextMenuStrip();
            menu.Font = new Font("Segoe UI", 9F);
            menu.Items.Add("Mở bảng điều khiển", null, delegate { ShowMainWindow(); });
            menu.Items.Add(new ToolStripSeparator());
            _toggleMenuItem = new ToolStripMenuItem("Hiện nút × trên tab đang chọn") { Checked = true, CheckOnClick = false };
            _toggleMenuItem.Click += delegate { SetOverlayEnabled(!_enabled); };
            menu.Items.Add(_toggleMenuItem);
            _startupMenuItem = new ToolStripMenuItem("Khởi chạy cùng Windows") { Checked = StartupManager.IsEnabled(), CheckOnClick = false };
            _startupMenuItem.Click += delegate { SetLaunchAtLogin(!_startupMenuItem.Checked); };
            menu.Items.Add(_startupMenuItem);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("Chẩn đoán…", null, delegate { ShowDiagnostics(); });
            menu.Items.Add("Mở cài đặt thanh tab Brave", null, delegate { OpenBraveAppearanceSettings(); });
            menu.Items.Add("Mở nhật ký", null, delegate { OpenLog(); });
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("Thoát ứng dụng", null, delegate { ConfirmExitApplication(); });

            _tray = new NotifyIcon();
            _tray.Icon = TrayIconFactory.CreateIcon();
            _tray.Text = AppInfo.ProductName;
            _tray.ContextMenuStrip = menu;
            _tray.Visible = true;
            _tray.MouseClick += delegate(object sender, MouseEventArgs e)
            {
                if (e.Button == MouseButtons.Left) ShowMainWindow();
            };
            _tray.DoubleClick += delegate { ShowMainWindow(); };

            _timer = new System.Windows.Forms.Timer();
            _timer.Interval = AppInfo.PollIntervalMilliseconds;
            _timer.Tick += OnTimerTick;
            _timer.Start();
            Log("Started version " + AppInfo.DisplayVersion + ". Waiting for a foreground Brave window.");
            Log("Win32 INPUT structure size=" + NativeMethods.GetInputStructureSize() + " bytes; expected=" + (IntPtr.Size == 8 ? 40 : 28) + " bytes on this process architecture.");
        }

        public void SetOverlayEnabled(bool enabled)
        {
            if (_enabled == enabled) return;
            if (!enabled)
            {
                DialogResult confirmation = MessageBox.Show(
                    "Tắt nút × tùy chỉnh? Nếu Brave đang bật “Always hide tab close button”, các nút đóng gốc vẫn bị ẩn. Bạn có thể phải mở Cài đặt Brave để khôi phục chúng.\r\n\r\nTiếp tục tắt nút ×?",
                    "Tắt nút ×", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (confirmation != DialogResult.Yes) return;
            }
            _enabled = enabled;
            _toggleMenuItem.Checked = enabled;
            if (!enabled)
            {
                _overlay.Hide();
                _lastWindow = IntPtr.Zero;
                _lastBounds = Rectangle.Empty;
                _lastTabName = String.Empty;
            }
            Log(enabled ? "Custom active-tab close button enabled." : "Custom active-tab close button disabled by user.");
            _mainForm.RefreshState();
        }

        public bool SetLaunchAtLogin(bool enabled)
        {
            try
            {
                StartupManager.SetEnabled(enabled);
                _startupMenuItem.Checked = enabled;
                _mainForm.UpdateStartupState(enabled);
                Log(enabled ? "Launch-at-login enabled." : "Launch-at-login disabled.");
                return true;
            }
            catch (Exception ex)
            {
                Log("Could not change launch-at-login setting: " + ex);
                MessageBox.Show("Không thể cập nhật khởi chạy cùng Windows. Hãy kiểm tra quyền truy cập Registry của tài khoản hiện tại.\r\n\r\n" + ex.Message,
                    AppInfo.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _startupMenuItem.Checked = StartupManager.IsEnabled();
                _mainForm.UpdateStartupState(_startupMenuItem.Checked);
                return false;
            }
        }

        private void OnTimerTick(object sender, EventArgs e)
        {
            try
            {
                IntPtr foreground = NativeMethods.GetForegroundRootWindow();
                bool braveIsForeground = foreground != IntPtr.Zero && NativeMethods.IsBraveWindow(foreground);
                if (braveIsForeground) _lastBraveWindow = foreground;

                bool diagnosticsVisible = _diagnostics != null && !_diagnostics.IsDisposed && _diagnostics.Visible;
                bool mainVisible = _mainForm != null && !_mainForm.IsDisposed && _mainForm.Visible;
                bool canInspectLastWindow = !braveIsForeground && (diagnosticsVisible || mainVisible) &&
                    _lastBraveWindow != IntPtr.Zero && NativeMethods.IsWindow(_lastBraveWindow) &&
                    NativeMethods.IsBraveWindow(_lastBraveWindow) && !NativeMethods.IsIconic(_lastBraveWindow);

                if (!_enabled || (!braveIsForeground && !canInspectLastWindow))
                {
                    _overlay.Hide();
                    _lastWindow = IntPtr.Zero;
                    _lastBounds = Rectangle.Empty;
                    _lastTabName = String.Empty;
                    ScanResult inactive = new ScanResult();
                    inactive.Status = !_enabled
                        ? "Nút × tùy chỉnh đang tắt. Bật lại từ bảng điều khiển hoặc menu khay hệ thống."
                        : "Brave chưa ở phía trước. Chuyển sang Brave để hiện nút ×; mở bảng điều khiển để xem trạng thái gần nhất.";
                    LastResult = inactive;
                    UpdateAllViews(inactive);
                    return;
                }

                IntPtr scanHwnd = braveIsForeground ? foreground : _lastBraveWindow;
                ScanResult result = TabScanner.Scan(scanHwnd);
                LastResult = result;
                UpdateAllViews(result);

                // Never display/click the overlay over another app, including this dashboard.
                if (!braveIsForeground)
                {
                    _overlay.Hide();
                    return;
                }

                TabInfo active = result.ActiveHorizontalTab;
                if (active == null)
                {
                    _overlay.Hide();
                    if (result.Error != null && (DateTime.Now - _lastErrorLog).TotalSeconds > 10)
                    {
                        Log("UI Automation scan error: " + result.Error);
                        _lastErrorLog = DateTime.Now;
                    }
                    return;
                }

                Rectangle target = TabScanner.GetOverlayBounds(active.Bounds);
                if (target == Rectangle.Empty)
                {
                    _overlay.Hide();
                    return;
                }

                if (_lastWindow != scanHwnd || _lastBounds != target || !String.Equals(_lastTabName, active.Name, StringComparison.Ordinal))
                {
                    _overlay.SetTarget(target);
                    _lastWindow = scanHwnd;
                    _lastBounds = target;
                    _lastTabName = active.Name;
                    Log("Active tab detected: '" + active.Name + "'; tab bounds=" + TabScanner.RectText(active.Bounds) + "; overlay=" + TabScanner.RectText(target));
                }
                else if (!_overlay.Visible)
                {
                    _overlay.SetTarget(target);
                }
            }
            catch (Exception ex)
            {
                _overlay.Hide();
                if ((DateTime.Now - _lastErrorLog).TotalSeconds > 10)
                {
                    Log("Unexpected polling error: " + ex);
                    _lastErrorLog = DateTime.Now;
                }
            }
        }

        private void UpdateAllViews(ScanResult result)
        {
            if (_diagnostics != null && !_diagnostics.IsDisposed) _diagnostics.UpdateResult(result);
            if (_mainForm != null && !_mainForm.IsDisposed) _mainForm.UpdateResult(result);
        }

        internal void TryCloseActiveTab()
        {
            try
            {
                if (!_enabled || !_overlay.Visible) return;
                IntPtr hwnd = NativeMethods.GetForegroundRootWindow();
                if (hwnd == IntPtr.Zero || !NativeMethods.IsBraveWindow(hwnd) || NativeMethods.IsIconic(hwnd))
                {
                    _overlay.Hide();
                    return;
                }

                ScanResult fresh = TabScanner.Scan(hwnd);
                LastResult = fresh;
                UpdateAllViews(fresh);
                TabInfo active = fresh.ActiveHorizontalTab;
                if (active == null)
                {
                    Log("Ignored × click: UI Automation could not confirm the active horizontal tab.");
                    _overlay.Hide();
                    return;
                }

                Point buttonCenter = new Point(_overlay.Left + (_overlay.Width / 2), _overlay.Top + (_overlay.Height / 2));
                Rectangle expectedOverlay = TabScanner.GetOverlayBounds(active.Bounds);
                if (!active.Bounds.Contains(buttonCenter) || expectedOverlay == Rectangle.Empty || _overlay.Bounds != expectedOverlay)
                {
                    Log("Ignored stale × click: the overlay no longer exactly matches the freshly confirmed active tab.");
                    _overlay.Hide();
                    return;
                }

                // Debounce rapid repeated clicks so a double-click cannot close the next tab.
                if ((DateTime.Now - _lastCloseAttempt).TotalMilliseconds < AppInfo.CloseDebounceMilliseconds)
                {
                    Log("Ignored repeated × click within the configured safety window.");
                    return;
                }
                _lastCloseAttempt = DateTime.Now;

                // WS_EX_NOACTIVATE keeps Brave foreground. Only send Ctrl+W after a fresh scan.
                if (!NativeMethods.IsBraveWindow(NativeMethods.GetForegroundRootWindow()))
                {
                    _overlay.Hide();
                    return;
                }
                string sendFailure;
                bool sent = NativeMethods.SendCtrlW(out sendFailure);
                Log(sent
                    ? "Sent Ctrl+W to the foreground Brave window."
                    : "Could not send Ctrl+W: " + sendFailure);
                if (!sent)
                {
                    _tray.BalloonTipTitle = AppInfo.ProductName;
                    _tray.BalloonTipText = "Không gửi được lệnh đóng tab. Mở Chẩn đoán để xem nhật ký.";
                    _tray.ShowBalloonTip(3500);
                }
            }
            catch (Exception ex)
            {
                Log("Could not close active tab: " + ex);
            }
        }

        private void ShowMainWindow()
        {
            if (_mainForm == null || _mainForm.IsDisposed) return;
            _mainForm.UpdateResult(LastResult);
            _mainForm.UpdateStartupState(StartupManager.IsEnabled());
            if (!_mainForm.Visible) _mainForm.Show();
            if (_mainForm.WindowState == FormWindowState.Minimized) _mainForm.WindowState = FormWindowState.Normal;
            _mainForm.BringToFront();
            _mainForm.Activate();
        }

        internal void ShowDiagnosticsFromMain()
        {
            ShowDiagnostics();
        }

        internal void RequestExitFromMain()
        {
            ExitApplication();
        }

        private void ConfirmExitApplication()
        {
            DialogResult answer = MessageBox.Show(
                "Thoát Xtension? Nút đóng tùy chỉnh sẽ ngừng hoạt động. Nếu Brave đang bật “Always hide tab close button”, nút đóng gốc cũng có thể vẫn bị ẩn cho đến khi bạn tắt tùy chọn đó trong Cài đặt Brave.\r\n\r\nBạn có chắc muốn thoát không?",
                "Thoát ứng dụng", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (answer == DialogResult.Yes) ExitApplication();
        }

        private void ShowDiagnostics()
        {
            if (_diagnostics == null || _diagnostics.IsDisposed)
            {
                _diagnostics = new DiagnosticsForm(this);
                _diagnostics.FormClosed += delegate { _diagnostics = null; };
            }
            _diagnostics.UpdateResult(LastResult);
            _diagnostics.Show();
            _diagnostics.WindowState = FormWindowState.Normal;
            _diagnostics.BringToFront();
            _diagnostics.Activate();
        }

        internal void OpenBraveAppearanceSettings()
        {
            try
            {
                Process[] processes = Process.GetProcessesByName("brave");
                if (processes.Length > 0)
                {
                    string exe = null;
                    try { exe = processes[0].MainModule.FileName; } catch { }
                    if (!String.IsNullOrEmpty(exe))
                    {
                        Process.Start(new ProcessStartInfo(exe, "brave://settings/appearance") { UseShellExecute = false });
                        return;
                    }
                }
                Process.Start(new ProcessStartInfo("brave://settings/appearance") { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể mở cài đặt tự động. Trong Brave, hãy mở:\r\nbrave://settings/appearance\r\n\r\n" + ex.Message,
                    AppInfo.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        internal void OpenLog()
        {
            try
            {
                AppPaths.EnsureDirectory();
                if (!File.Exists(AppPaths.LogFile)) File.WriteAllText(AppPaths.LogFile, AppInfo.ProductName + " log\r\n", Encoding.UTF8);
                Process.Start(new ProcessStartInfo("notepad.exe", "\"" + AppPaths.LogFile + "\"") { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể mở nhật ký:\r\n" + ex.Message, AppInfo.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        internal void ShowTrayTip(string title, string message)
        {
            try
            {
                _tray.BalloonTipTitle = title;
                _tray.BalloonTipText = message;
                _tray.ShowBalloonTip(2500);
            }
            catch { }
        }

        internal static void Log(string message)
        {
            try
            {
                AppPaths.EnsureDirectory();
                FileInfo info = new FileInfo(AppPaths.LogFile);
                if (info.Exists && info.Length > AppInfo.LogRotationThresholdBytes)
                {
                    string previous = AppPaths.LogFile + ".old";
                    if (File.Exists(previous)) File.Delete(previous);
                    File.Move(AppPaths.LogFile, previous);
                }
                File.AppendAllText(AppPaths.LogFile, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + "  " + message + Environment.NewLine, Encoding.UTF8);
            }
            catch { }
        }

        private void ExitApplication()
        {
            _isExiting = true;
            Log("Application exit requested by user.");
            ExitThread();
        }

        protected override void ExitThreadCore()
        {
            _isExiting = true;
            ApplicationContextHolder.Context = null;
            try { _timer.Stop(); _timer.Dispose(); } catch { }
            try { _overlay.Close(); _overlay.Dispose(); } catch { }
            try { if (_diagnostics != null) _diagnostics.Close(); } catch { }
            try
            {
                if (_mainForm != null && !_mainForm.IsDisposed)
                {
                    _mainForm.PrepareForExit();
                    _mainForm.Close();
                }
            }
            catch { }
            try { _tray.Visible = false; _tray.Dispose(); } catch { }
            base.ExitThreadCore();
        }
    }

}
