using System;
using System.Threading;
using System.Windows.Forms;

namespace Xtension
{
    internal static class Program
    {
        private static Mutex _instanceMutex;

        [STAThread]
        private static void Main()
        {
            bool createdNew;
            try
            {
                _instanceMutex = new Mutex(true, @"Local\Xtension", out createdNew);
                if (!createdNew)
                {
                    MessageBox.Show("Xtension đang chạy ở khay hệ thống. Nhấp biểu tượng của ứng dụng gần đồng hồ Windows để mở bảng điều khiển.",
                        AppInfo.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    try { if (_instanceMutex != null) _instanceMutex.Dispose(); } catch { }
                    return;
                }
            }
            catch (Exception ex)
            {
                SafeLog("Single-instance mutex could not be initialized: " + ex);
            }

            try
            {
                NativeMethods.EnableBestDpiAwareness();
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                Application.ThreadException += delegate(object sender, System.Threading.ThreadExceptionEventArgs e)
                {
                    SafeLog("UI thread exception: " + e.Exception);
                };
                AppDomain.CurrentDomain.UnhandledException += delegate(object sender, UnhandledExceptionEventArgs e)
                {
                    SafeLog("Unhandled exception (terminating=" + e.IsTerminating + "): " + e.ExceptionObject);
                };
                Application.Run(new TrayAppContext());
            }
            catch (Exception ex)
            {
                SafeLog("Fatal startup/runtime exception: " + ex);
                MessageBox.Show("Xtension gặp lỗi và cần đóng. Nhật ký nằm tại:\r\n" + AppPaths.LogFile + "\r\n\r\n" + ex.Message,
                    AppInfo.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                try
                {
                    if (_instanceMutex != null)
                    {
                        _instanceMutex.ReleaseMutex();
                        _instanceMutex.Dispose();
                    }
                }
                catch { }
            }
        }

        private static void SafeLog(string message)
        {
            try { TrayAppContext.Log(message); } catch { }
        }
    }

}
