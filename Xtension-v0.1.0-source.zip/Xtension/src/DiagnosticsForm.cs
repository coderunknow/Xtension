using System;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace Xtension
{
    internal sealed class DiagnosticsForm : Form
    {
        private readonly TrayAppContext _context;
        private readonly Label _status;
        private readonly ListView _list;
        private readonly Label _hint;
        private string _lastSignature = String.Empty;

        public DiagnosticsForm(TrayAppContext context)
        {
            _context = context;
            Text = AppInfo.ProductName + " — Chẩn đoán";
            MinimumSize = new Size(720, 400);
            Size = new Size(980, 540);
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Segoe UI", 9F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(245, 247, 250);

            _status = new Label();
            _status.Dock = DockStyle.Top;
            _status.Height = 54;
            _status.Padding = new Padding(12, 8, 8, 8);
            _status.BackColor = Color.White;
            _status.ForeColor = Color.FromArgb(31, 41, 55);
            _status.Text = "Đang chờ kết quả quét…";

            _hint = new Label();
            _hint.Dock = DockStyle.Bottom;
            _hint.Height = 60;
            _hint.Padding = new Padding(12, 8, 8, 8);
            _hint.BackColor = Color.FromArgb(235, 239, 245);
            _hint.ForeColor = Color.FromArgb(71, 85, 105);
            _hint.Text = "Nếu không xác nhận được tab đang chọn, nút × sẽ bị ẩn để tránh đóng nhầm. Mở Nhật ký từ khay hệ thống để xem lỗi.";

            _list = new ListView();
            _list.Dock = DockStyle.Fill;
            _list.View = View.Details;
            _list.FullRowSelect = true;
            _list.GridLines = true;
            _list.BorderStyle = BorderStyle.FixedSingle;
            _list.Font = new Font("Segoe UI", 9F);
            _list.Columns.Add("Tab / tên truy cập", 270);
            _list.Columns.Add("Đang chọn", 85);
            _list.Columns.Add("Có trạng thái", 115);
            _list.Columns.Add("Vị trí màn hình (px)", 200);
            _list.Columns.Add("Tab ngang", 155);

            Controls.Add(_list);
            Controls.Add(_hint);
            Controls.Add(_status);
        }

        public void UpdateResult(ScanResult result)
        {
            if (IsDisposed || result == null) return;
            StringBuilder signatureBuilder = new StringBuilder(128);
            signatureBuilder.Append(result.Status).Append('|').Append(result.WindowTitle).Append('|').Append(result.ActiveHorizontalTabName);
            for (int i = 0; i < result.Tabs.Count; i++)
            {
                TabInfo tab = result.Tabs[i];
                signatureBuilder.Append('|').Append(tab.Name).Append(':').Append(tab.Selected).Append(':').Append(tab.Bounds);
            }
            string signature = signatureBuilder.ToString();
            if (String.Equals(signature, _lastSignature, StringComparison.Ordinal)) return;
            _lastSignature = signature;

            _status.Text = result.Status + (String.IsNullOrEmpty(result.WindowTitle) ? String.Empty : "  Cửa sổ: " + result.WindowTitle);
            _list.BeginUpdate();
            _list.Items.Clear();
            foreach (TabInfo tab in result.Tabs)
            {
                ListViewItem item = new ListViewItem(String.IsNullOrEmpty(tab.Name) ? "(unnamed TabItem)" : tab.Name);
                item.SubItems.Add(tab.SelectionKnown ? (tab.Selected ? "YES" : "no") : "unknown");
                item.SubItems.Add(tab.SelectionKnown ? "YES" : "no");
                item.SubItems.Add(TabScanner.RectText(tab.Bounds));
                item.SubItems.Add(tab.IsHorizontalCandidate ? "yes" : "no");
                if (tab.Selected && tab.IsHorizontalCandidate) item.BackColor = Color.FromArgb(220, 245, 220);
                _list.Items.Add(item);
            }
            _list.EndUpdate();

            if (result.ActiveHorizontalTab == null)
            {
                _hint.Text = "Không xác nhận được tab ngang đang hoạt động. Nút × được ẩn để tránh đóng nhầm. Kiểm tra các cột bên dưới hoặc mở nhật ký từ khay hệ thống.";
            }
            else
            {
                _hint.Text = "Đã xác nhận tab đang chọn: " + result.ActiveHorizontalTab.Name + ". Dòng xanh là tab được nhận diện; nút × nằm sát mép phải tab đó.";
            }
        }
    }

}
