using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Xtension")]
[assembly: AssemblyDescription("A safe close-button overlay for the selected Brave browser tab")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("coderunknow")]
[assembly: AssemblyProduct("Xtension")]
[assembly: AssemblyCopyright("Copyright © 2026 coderunknow")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("2ae34d69-ea9c-4e59-a4e4-021cd7d12010")]
[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]
