using System;

namespace Xtension
{
    /// <summary>Centralized product metadata and bounded runtime settings.</summary>
    internal static class AppInfo
    {
        public const string Version = "0.1.0";
        public const string DisplayVersion = "v0.1.0";
        public const string ProductName = "Xtension";
        public const int PollIntervalMilliseconds = 650;
        public const int CloseDebounceMilliseconds = 650;
        public const int LogRotationThresholdBytes = 1024 * 1024;
    }
}
