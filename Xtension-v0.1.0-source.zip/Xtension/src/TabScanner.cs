using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Automation;
using System.Windows.Forms;

namespace Xtension
{
    internal sealed class ScanResult
    {
        public string Status = String.Empty;
        public string WindowTitle = String.Empty;
        public string Error;
        public readonly List<TabInfo> Tabs = new List<TabInfo>();
        public TabInfo ActiveHorizontalTab;
        public string ActiveHorizontalTabName { get { return ActiveHorizontalTab == null ? String.Empty : ActiveHorizontalTab.Name; } }
    }


    internal sealed class TabInfo
    {
        public string Name = String.Empty;
        public Rectangle Bounds = Rectangle.Empty;
        public bool SelectionKnown;
        public bool Selected;
        public bool IsOffscreen;
        public bool IsHorizontalCandidate;
        public int Depth;
    }


    internal static class TabScanner
    {
        private const int MaxNodes = 450;
        private const int MaxDepth = 9;

        public static ScanResult Scan(IntPtr hwnd)
        {
            ScanResult result = new ScanResult();
            result.Status = "Đang quét cây giao diện trợ năng của Brave…";
            result.WindowTitle = NativeMethods.GetWindowTitle(hwnd);
            try
            {
                Rectangle window = NativeMethods.GetWindowBounds(hwnd);
                AutomationElement root = AutomationElement.FromHandle(hwnd);
                if (root == null)
                {
                    result.Status = "UI Automation không trả về phần tử gốc của cửa sổ Brave.";
                    return result;
                }

                TreeWalker walker = TreeWalker.ControlViewWalker;
                int visited = 0;
                WalkSubtree(root, walker, window, 0, ref visited, result);

                foreach (TabInfo tab in result.Tabs)
                    tab.IsHorizontalCandidate = IsHorizontalCandidate(tab.Bounds, window) && !tab.IsOffscreen;

                List<TabInfo> selected = new List<TabInfo>();
                foreach (TabInfo tab in result.Tabs)
                    if (tab.SelectionKnown && tab.Selected && tab.IsHorizontalCandidate) selected.Add(tab);

                if (selected.Count == 1)
                {
                    result.ActiveHorizontalTab = selected[0];
                    result.Status = "Đã xác nhận tab đang chọn. Đã quét " + visited + " phần tử UIA; tìm thấy " + result.Tabs.Count + " tab.";
                }
                else if (selected.Count > 1)
                {
                    // Browser chrome is expected to be at the top of the window. If more
                    // than one selected TabItem survives the geometry filter, do not guess.
                    result.Status = "Không thể phân biệt chắc chắn giữa " + selected.Count + " tab được đánh dấu đang chọn trong vùng thanh tab ngang. Đã ẩn nút × để tránh đóng nhầm.";
                }
                else if (result.Tabs.Count == 0)
                {
                    result.Status = "Không tìm thấy điều khiển tab trong " + visited + " phần tử UIA đầu tiên. Đã ẩn nút ×.";
                }
                else
                {
                    result.Status = "Tìm thấy " + result.Tabs.Count + " tab nhưng không xác nhận được tab đang chọn trong thanh tab ngang. Đã ẩn nút ×.";
                }
            }
            catch (Exception ex)
            {
                result.Error = ex.GetType().Name + ": " + ex.Message;
                result.Status = "Quét UI Automation thất bại. Đã ẩn nút ×: " + result.Error;
            }
            return result;
        }

        private static void WalkSubtree(AutomationElement current, TreeWalker walker, Rectangle window, int depth, ref int visited, ScanResult result)
        {
            if (current == null || visited >= MaxNodes) return;
            visited++;

            ControlType controlType = null;
            try { controlType = current.Current.ControlType; }
            catch (ElementNotAvailableException) { return; }
            catch (InvalidOperationException) { return; }
            catch (System.Runtime.InteropServices.COMException) { return; }

            if (controlType == ControlType.TabItem)
            {
                TabInfo info = ReadTab(current, depth, window);
                if (info != null) result.Tabs.Add(info);
            }

            // Never descend into page content; that can make accessibility scans expensive.
            if (controlType == ControlType.Document || depth >= MaxDepth) return;

            try
            {
                AutomationElement child = walker.GetFirstChild(current);
                int siblingGuard = 0;
                while (child != null && siblingGuard < 100 && visited < MaxNodes)
                {
                    AutomationElement next = null;
                    try { next = walker.GetNextSibling(child); }
                    catch (ElementNotAvailableException) { }
                    catch (InvalidOperationException) { }
                    catch (System.Runtime.InteropServices.COMException) { }

                    WalkSubtree(child, walker, window, depth + 1, ref visited, result);
                    siblingGuard++;
                    child = next;
                }
            }
            catch (ElementNotAvailableException) { }
            catch (InvalidOperationException) { }
            catch (System.Runtime.InteropServices.COMException) { }
        }

        private static TabInfo ReadTab(AutomationElement element, int depth, Rectangle window)
        {
            try
            {
                AutomationElement.AutomationElementInformation current = element.Current;
                TabInfo info = new TabInfo();
                info.Name = current.Name ?? String.Empty;
                info.Bounds = ToRectangle(current.BoundingRectangle);
                info.IsOffscreen = current.IsOffscreen;
                info.Depth = depth;
                try
                {
                    object patternObject;
                    if (element.TryGetCurrentPattern(SelectionItemPattern.Pattern, out patternObject))
                    {
                        info.SelectionKnown = true;
                        info.Selected = ((SelectionItemPattern)patternObject).Current.IsSelected;
                    }
                }
                catch (ElementNotAvailableException) { }
                catch (InvalidOperationException) { }
                catch (System.Runtime.InteropServices.COMException) { }
                return info;
            }
            catch
            {
                return null;
            }
        }

        private static bool IsHorizontalCandidate(Rectangle bounds, Rectangle window)
        {
            if (bounds == Rectangle.Empty) return false;
            if (bounds.Width < 55 || bounds.Width > 650) return false;
            if (bounds.Height < 16 || bounds.Height > 65) return false;
            if (bounds.Top < window.Top - 5 || bounds.Top > window.Top + 105) return false;
            if (bounds.Bottom > window.Top + 120) return false;
            if (bounds.Left < window.Left - 5 || bounds.Right > window.Right + 5) return false;
            return true;
        }

        public static Rectangle GetOverlayBounds(Rectangle tabBounds)
        {
            if (tabBounds == Rectangle.Empty || tabBounds.Width < 55 || tabBounds.Height < 16) return Rectangle.Empty;
            const int size = 26;
            int x = tabBounds.Right - size - 3;
            int y = tabBounds.Top + (tabBounds.Height - size) / 2;
            return new Rectangle(x, y, size, size);
        }

        private static Rectangle ToRectangle(System.Windows.Rect bounds)
        {
            try
            {
                if (Double.IsNaN(bounds.X) || Double.IsNaN(bounds.Y) || Double.IsInfinity(bounds.X) || Double.IsInfinity(bounds.Y)) return Rectangle.Empty;
                return Rectangle.FromLTRB((int)Math.Round(bounds.Left), (int)Math.Round(bounds.Top), (int)Math.Round(bounds.Right), (int)Math.Round(bounds.Bottom));
            }
            catch { return Rectangle.Empty; }
        }

        public static string RectText(Rectangle r)
        {
            if (r == Rectangle.Empty) return "(empty)";
            return String.Format("L{0} T{1} W{2} H{3}", r.Left, r.Top, r.Width, r.Height);
        }
    }

}
