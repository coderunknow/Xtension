using System;
using System.Drawing;
using System.Windows.Forms;

namespace Xtension
{
    internal sealed class MainForm : Form
    {
        private readonly TrayAppContext _context;
        private readonly Label _statusBadge;
        private readonly Label _statusTitle;
        private readonly Label _statusDetail;
        private readonly Label _tabName;
        private readonly Label _notice;
        private readonly Button _toggleButton;
        private readonly CheckBox _startupCheckBox;
        private readonly Label _footer;
        private string _lastSignature = String.Empty;
        private bool _suppressStartupEvent;
        private bool _allowClose;
        private bool _closeTipShown;
        private readonly Color _navy = Color.FromArgb(24, 34, 51);
        private readonly Color _blue = Color.FromArgb(37, 99, 235);
        private readonly Color _green = Color.FromArgb(5, 150, 105);
        private readonly Color _red = Color.FromArgb(185, 28, 28);
        private readonly Color _text = Color.FromArgb(31, 41, 55);
        private readonly Color _muted = Color.FromArgb(100, 116, 139);
        private readonly Color _surface = Color.White;

        public MainForm(TrayAppContext context)
        {
            _context = context;
            Text = AppInfo.ProductName;
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(720, 560);
            MinimumSize = new Size(660, 520);
            MaximizeBox = false;
            MinimizeBox = true;
            ShowInTaskbar = true;
            BackColor = Color.FromArgb(243, 246, 250);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular);
            AutoScaleMode = AutoScaleMode.Font;
            KeyPreview = true;

            Panel header = new Panel { Dock = DockStyle.Top, Height = 86, BackColor = _navy, Padding = new Padding(22, 14, 20, 10) };
            Label title = new Label { Text = AppInfo.ProductName, AutoSize = true, Location = new Point(22, 13), Font = new Font("Segoe UI", 17F, FontStyle.Bold), ForeColor = Color.White };
            Label subtitle = new Label { Text = "Chỉ hiện nút đóng trên tab Brave đang được chọn", AutoSize = true, Location = new Point(24, 48), Font = new Font("Segoe UI", 9.5F), ForeColor = Color.FromArgb(203, 213, 225) };
            header.Controls.Add(title);
            header.Controls.Add(subtitle);

            Panel footerPanel = new Panel { Dock = DockStyle.Bottom, Height = 32, BackColor = Color.FromArgb(235, 239, 245), Padding = new Padding(18, 0, 18, 0) };
            _footer = new Label { Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, ForeColor = _muted, Text = "Phiên bản " + AppInfo.DisplayVersion + " · Đóng cửa sổ này sẽ thu nhỏ ứng dụng xuống khay hệ thống." };
            footerPanel.Controls.Add(_footer);

            TableLayoutPanel content = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                Padding = new Padding(18, 16, 18, 14),
                BackColor = BackColor
            };
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            content.RowStyles.Add(new RowStyle(SizeType.Absolute, 132F));
            content.RowStyles.Add(new RowStyle(SizeType.Absolute, 64F));
            content.RowStyles.Add(new RowStyle(SizeType.Absolute, 74F));
            content.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

            Panel statusCard = CreateCard();
            _statusBadge = new Label
            {
                Text = "●  ĐANG KHỞI ĐỘNG",
                AutoSize = true,
                Location = new Point(18, 15),
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = _blue
            };
            _statusTitle = new Label
            {
                Text = "Đang kiểm tra tab Brave…",
                AutoEllipsis = true,
                Location = new Point(18, 42),
                Size = new Size(630, 27),
                Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                ForeColor = _text
            };
            Label activeLabel = new Label { Text = "TAB ĐƯỢC NHẬN DIỆN", AutoSize = true, Location = new Point(19, 77), Font = new Font("Segoe UI", 7.5F, FontStyle.Bold), ForeColor = _muted };
            _tabName = new Label { Text = "Chưa có tab được xác nhận", AutoEllipsis = true, Location = new Point(19, 94), Size = new Size(630, 22), Font = new Font("Segoe UI", 9F), ForeColor = _text };
            statusCard.Controls.Add(_statusBadge);
            statusCard.Controls.Add(_statusTitle);
            statusCard.Controls.Add(activeLabel);
            statusCard.Controls.Add(_tabName);
            statusCard.Resize += delegate
            {
                int width = Math.Max(120, statusCard.ClientSize.Width - 38);
                _statusTitle.Width = width;
                _tabName.Width = width;
            };
            content.Controls.Add(statusCard, 0, 0);

            FlowLayoutPanel toggleRow = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, Padding = new Padding(0, 9, 0, 0), BackColor = BackColor };
            _toggleButton = CreateButton("Tắt nút ×", _red, Color.White, 166, 40);
            _toggleButton.Margin = new Padding(0, 0, 18, 0);
            _toggleButton.Click += delegate { _context.SetOverlayEnabled(!_context.OverlayEnabled); UpdateToggleButton(); RefreshState(); };
            _startupCheckBox = new CheckBox
            {
                Text = "Khởi chạy cùng Windows",
                AutoSize = true,
                Margin = new Padding(2, 12, 0, 0),
                ForeColor = _text,
                Font = new Font("Segoe UI", 9.5F),
                UseVisualStyleBackColor = false,
                BackColor = BackColor
            };
            _startupCheckBox.Checked = StartupManager.IsEnabled();
            _startupCheckBox.CheckedChanged += delegate
            {
                if (_suppressStartupEvent) return;
                _context.SetLaunchAtLogin(_startupCheckBox.Checked);
            };
            toggleRow.Controls.Add(_toggleButton);
            toggleRow.Controls.Add(_startupCheckBox);
            content.Controls.Add(toggleRow, 0, 1);

            FlowLayoutPanel actions = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = true, Padding = new Padding(0, 10, 0, 4), BackColor = BackColor };
            Button diagnosticsButton = CreateButton("Chẩn đoán", Color.FromArgb(226, 232, 240), _text, 126, 38);
            diagnosticsButton.Click += delegate { _context.ShowDiagnosticsFromMain(); };
            Button settingsButton = CreateButton("Cài đặt Brave", Color.FromArgb(226, 232, 240), _text, 126, 38);
            settingsButton.Click += delegate { _context.OpenBraveAppearanceSettings(); };
            Button logButton = CreateButton("Mở nhật ký", Color.FromArgb(226, 232, 240), _text, 126, 38);
            logButton.Click += delegate { _context.OpenLog(); };
            Button exitButton = CreateButton("Thoát ứng dụng", Color.FromArgb(254, 226, 226), _red, 132, 38);
            exitButton.Click += delegate
            {
                DialogResult answer = MessageBox.Show("Thoát Xtension? Nút × tùy chỉnh sẽ ngừng hoạt động. Nếu Brave đang bật “Always hide tab close button”, nút đóng gốc cũng có thể vẫn bị ẩn cho đến khi bạn tắt tùy chọn đó trong Cài đặt Brave.\r\n\r\nBạn có chắc muốn thoát không?",
                    "Thoát ứng dụng", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (answer == DialogResult.Yes) _context.RequestExitFromMain();
            };
            diagnosticsButton.Margin = new Padding(0, 0, 8, 4);
            settingsButton.Margin = new Padding(0, 0, 8, 4);
            logButton.Margin = new Padding(0, 0, 8, 4);
            exitButton.Margin = new Padding(0, 0, 0, 4);
            actions.Controls.Add(diagnosticsButton);
            actions.Controls.Add(settingsButton);
            actions.Controls.Add(logButton);
            actions.Controls.Add(exitButton);
            content.Controls.Add(actions, 0, 2);

            Panel noticeCard = CreateCard();
            _notice = new Label
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(14, 10, 12, 8),
                ForeColor = _muted,
                Font = new Font("Segoe UI", 8.5F),
                Text = "Lưu ý: Nếu tắt nút × tùy chỉnh, nút đóng gốc của Brave vẫn bị ẩn khi tùy chọn “Always hide tab close button” đang bật. Mở Cài đặt Brave để khôi phục nút gốc."
            };
            noticeCard.Controls.Add(_notice);
            content.Controls.Add(noticeCard, 0, 3);

            Controls.Add(content);
            Controls.Add(footerPanel);
            Controls.Add(header);

            FormClosing += OnFormClosing;
            KeyDown += delegate(object sender, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Escape) { Hide(); e.Handled = true; }
            };
            RefreshState();
        }

        private Panel CreateCard()
        {
            Panel panel = new Panel { Dock = DockStyle.Fill, BackColor = _surface, Margin = new Padding(0, 0, 0, 0), Padding = new Padding(0) };
            panel.Paint += delegate(object sender, PaintEventArgs e)
            {
                using (Pen pen = new Pen(Color.FromArgb(221, 228, 237)))
                    e.Graphics.DrawRectangle(pen, 0, 0, panel.Width - 1, panel.Height - 1);
            };
            return panel;
        }

        private Button CreateButton(string caption, Color backColor, Color foreColor, int width, int height)
        {
            Button button = new Button
            {
                Text = caption,
                Size = new Size(width, height),
                BackColor = backColor,
                ForeColor = foreColor,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand,
                UseVisualStyleBackColor = false,
                TabStop = true
            };
            button.FlatAppearance.BorderSize = 0;
            button.FlatAppearance.MouseOverBackColor = ControlPaint.Light(backColor, 0.08F);
            button.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(backColor, 0.06F);
            return button;
        }

        public void RefreshState()
        {
            UpdateResult(_context.LastResult);
            UpdateToggleButton();
            UpdateStartupState(StartupManager.IsEnabled());
        }

        private void UpdateToggleButton()
        {
            if (_toggleButton == null) return;
            bool enabled = _context.OverlayEnabled;
            _toggleButton.Text = enabled ? "Tắt nút ×" : "Bật nút ×";
            _toggleButton.BackColor = enabled ? _red : _green;
            _toggleButton.ForeColor = Color.White;
            _toggleButton.FlatAppearance.MouseOverBackColor = ControlPaint.Light(_toggleButton.BackColor, 0.08F);
            _toggleButton.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(_toggleButton.BackColor, 0.06F);
        }

        public void UpdateStartupState(bool enabled)
        {
            if (_startupCheckBox == null || _startupCheckBox.IsDisposed) return;
            _suppressStartupEvent = true;
            _startupCheckBox.Checked = enabled;
            _suppressStartupEvent = false;
        }

        public void UpdateResult(ScanResult result)
        {
            if (IsDisposed || result == null || _statusTitle == null) return;
            string signature = (_context.OverlayEnabled ? "on" : "off") + "|" + _context.OverlayVisible + "|" + result.Status + "|" + result.WindowTitle + "|" + result.ActiveHorizontalTabName;
            if (signature == _lastSignature) return;
            _lastSignature = signature;

            if (!_context.OverlayEnabled)
            {
                _statusBadge.Text = "●  NÚT × ĐANG TẮT";
                _statusBadge.ForeColor = _red;
                _statusTitle.Text = "Lớp phủ đã được tạm dừng";
                _statusDetailFallback();
            }
            else if (result.ActiveHorizontalTab != null)
            {
                _statusBadge.Text = _context.OverlayVisible ? "●  ĐANG HOẠT ĐỘNG" : "●  SẴN SÀNG";
                _statusBadge.ForeColor = _context.OverlayVisible ? _green : _blue;
                _statusTitle.Text = _context.OverlayVisible ? "Nút × đang gắn với tab được chọn" : "Đã nhận diện tab — chờ bạn quay lại Brave";
                _notice.Text = "Tab được nhận diện thành công. Nếu vẫn thấy nút × gốc trên các tab khác, bật “Always hide tab close button” trong Cài đặt Brave. Nút tùy chỉnh chỉ xuất hiện khi Brave ở phía trước.";
            }
            else
            {
                bool waitingForBrave = result.Status.IndexOf("Brave chưa ở phía trước", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    result.Status.IndexOf("Đang khởi động", StringComparison.OrdinalIgnoreCase) >= 0;
                _statusBadge.Text = waitingForBrave ? "●  CHỜ BRAVE" : "●  CHƯA NHẬN DIỆN";
                _statusBadge.ForeColor = _muted;
                _statusTitle.Text = waitingForBrave ? "Mở Brave để bắt đầu" : "Chưa xác nhận được tab đang chọn";
                _notice.Text = result.Status + "\r\nKiểm tra “Always hide tab close button” trong Cài đặt Brave. Nếu vẫn không nhận diện được tab, mở Chẩn đoán; nút × sẽ tiếp tục ẩn để tránh đóng nhầm.";
            }
            _tabName.Text = result.ActiveHorizontalTab == null ? "Chưa có tab được xác nhận" : (String.IsNullOrEmpty(result.ActiveHorizontalTab.Name) ? "(tab không có tiêu đề)" : result.ActiveHorizontalTab.Name);
            _footer.Text = "Phiên bản " + AppInfo.DisplayVersion + " · Đóng cửa sổ này sẽ thu nhỏ ứng dụng xuống khay hệ thống.";
        }

        private void _statusDetailFallback()
        {
            _notice.Text = "Nút × tùy chỉnh đang tắt. Lưu ý: nút đóng gốc của Brave vẫn bị ẩn nếu “Always hide tab close button” đang bật. Mở Cài đặt Brave để khôi phục nút gốc.";
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (_allowClose || e.CloseReason == CloseReason.WindowsShutDown || e.CloseReason == CloseReason.TaskManagerClosing) return;
            e.Cancel = true;
            Hide();
            if (!_closeTipShown)
            {
                _closeTipShown = true;
                _context.ShowTrayTip("Ứng dụng vẫn đang chạy", "Xtension đã thu nhỏ xuống khay hệ thống. Nhấp biểu tượng gần đồng hồ để mở lại.");
            }
        }

        public void PrepareForExit() { _allowClose = true; }
    }

}
