# Xtension v0.1.0

Xtension is a small Windows utility that displays one custom `×` button on the currently selected **horizontal Brave tab**. It uses Windows UI Automation to confirm the selected tab, then sends `Ctrl+W` only after a fresh safety scan. The non-activating overlay is designed to keep Brave in the foreground.

> **Release status:** source and static checks are prepared, but this authoring environment cannot compile or exercise Windows UI Automation. GitHub Actions is configured to compile x86/x64 Windows binaries when `v0.1.0` is tagged. Do not consider a release production-verified until CI and the target-device checklist pass.

## Capabilities

- Dashboard and notification-area (tray) controls.
- One custom `×` on the selected horizontal Brave tab; fail-closed when tab selection is ambiguous.
- Fresh UI Automation validation before closing, exact overlay/tab bounds validation, and a debounce window against accidental double-clicks.
- Optional current-user startup entry, disabled by default; no administrator rights are requested.
- Single-instance guard, DPI-aware manifest, exception logging and rotating logs.
- UI scanner bounded by maximum tree nodes and depth. The poll interval is set to 650 ms to reduce repeated scans; close clicks still perform an immediate fresh scan.
- x86 and x64 Windows build assets through GitHub Actions.

## Compatibility

- Windows 10 or later with Brave for Windows.
- Horizontal tab strip only. Vertical tabs and non-standard Brave layouts are not supported.
- This is **Windows-only**, not a macOS/Linux application. “Multi-platform” release assets currently mean Windows x86 and Windows x64 architectures.
- The app needs the .NET Framework 4.8 runtime. Building from source requires a matching .NET Framework C# compiler and UI Automation reference assemblies; Visual Studio Build Tools / .NET Framework Developer Pack can provide them.

## Build from source

1. Extract the source or clone the repository.
2. Open a terminal in the repository directory.
3. Run `powershell -NoProfile -ExecutionPolicy Bypass -File .\verify-source.ps1` for static source/package checks.
4. Run `build.bat x64` for 64-bit Windows or `build.bat x86` for 32-bit Windows.
5. The EXE is written to `dist\Xtension-win-x64.exe` or `dist\Xtension-win-x86.exe`.

You can also open `Xtension.csproj` in Visual Studio with the .NET Framework 4.8 targeting pack installed and build Release (Any CPU). `build.bat` is the canonical architecture-specific build path used by CI.

## Brave configuration

1. Open `brave://settings/appearance`.
2. Enable **Always hide tab close button** if your Brave version exposes this setting. Xtension draws a replacement button; it does not modify Brave's native UI.
3. Launch Xtension and keep Brave focused with a regular horizontal tab strip.
4. The overlay should appear only when the active tab can be determined unambiguously.

**Important:** When the overlay is disabled or Xtension exits, Brave's native close buttons are not automatically restored. If the hide setting remains on, close buttons may remain hidden until that Brave setting is disabled or Xtension is re-enabled.

Xtension only replaces the visible button workflow. It does not block other close paths such as `Ctrl+W`, middle-click, or browser menu commands.

## Diagnostics and logs

The tray menu provides diagnostics, Brave appearance settings, log access, and application exit. Logs are stored under `%LOCALAPPDATA%\Xtension\app.log` and rotate at approximately 1 MiB. Log entries may include tab/window titles; review them before sharing if those names are private.

If the overlay is absent, the app intentionally hides it rather than guessing. Check the diagnostics window and log instead of bypassing safety checks.

## Push and publish from Windows

To publish this prepared source from an authenticated clone:

1. Install Git for Windows and authenticate using Git Credential Manager or GitHub CLI.
2. Run `git clone https://github.com/coderunknow/Xtension.git`.
3. Extract this source ZIP, then copy the contents of the `Xtension` folder into the cloned repository, preserving its `.git` folder and existing `LICENSE`.
4. Run `publish-to-github.bat` from the cloned repository. It checks the origin, branch, static source validation, whitespace, and whether tag `v0.1.0` already exists. It never force-pushes or overwrites a tag.
5. Watch GitHub Actions. The release workflow publishes the two EXEs and source ZIP only if both architecture builds pass.

If the script stops at authentication or push, resolve that Git/GitHub permission issue before retrying; it intentionally does not force-push.

## Release pipeline

- `.github/workflows/ci.yml` validates source consistency and compiles Windows x86/x64 binaries on pushes and pull requests.
- `.github/workflows/release.yml` runs when a `v*` tag is pushed, builds both architectures, then creates a GitHub Release with the EXEs and a source ZIP.
- The intended initial tag is `v0.1.0`. The release job itself will only run after the tag exists and CI succeeds.

## Acceptance checklist before relying on it

1. CI build passes for both x86 and x64.
2. Start Xtension; confirm only one tray icon and one process instance.
3. Switch quickly among Brave tabs and confirm the `×` follows only the selected tab.
4. Click `×`; confirm only the active tab closes and Brave remains foreground.
5. Change tabs immediately before clicking; stale-position validation must prevent closing a different tab.
6. Switch to another application, minimize Brave, and verify the overlay hides.
7. Toggle the overlay from the dashboard and tray menu.
8. Exit Xtension; confirm its process ends and the overlay disappears.
9. Test Windows display scaling, maximized/restored windows, pinned tabs, many tabs, and Brave updates.
10. Confirm the log reports no repeated UI Automation failures or SendInput errors.

## Security and known limitations

- No elevation, browser injection, remote network calls, or external telemetry.
- Uses Win32 `SendInput` to send `Ctrl+W` after a fresh tab scan. Windows UIPI may block input if Brave and Xtension run at different integrity levels; run both at the same normal privilege level.
- UI Automation tree structure can vary by Brave version or accessibility settings. If selection cannot be confirmed, the overlay remains hidden.
- CI compilation is necessary but not sufficient to establish runtime safety. High-DPI and real browser acceptance tests must pass on Windows before describing this release as fully production-ready.
