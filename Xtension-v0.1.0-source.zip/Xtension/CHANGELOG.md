# Changelog

## v0.1.0

- Initial public Xtension release candidate.
- Renamed the application, namespace, mutex, startup registry value, and local log directory to `Xtension`.
- Centralized version, polling cadence, close debounce, and log rotation threshold.
- Split the former monolithic C# file into focused program, tray context, UI, scanner, and Win32 interop files.
- Replaced per-container child-list allocations and heap-allocated traversal nodes with a bounded depth-first scanner.
- Changed diagnostics signature construction to use `StringBuilder` and ordinal comparison.
- Added reproducible Windows x86/x64 build scripts and GitHub Actions CI/release workflows.
- Retained fail-closed tab detection, fresh close-time scan, UIA/node/depth bounds, single-instance guard, DPI manifest, and log rotation.
- Release caveat: the current authoring environment cannot run Windows builds or UI Automation acceptance tests; do not infer runtime verification from static checks alone.
