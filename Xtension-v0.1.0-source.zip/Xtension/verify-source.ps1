$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$required = @(
    'src\Program.cs', 'src\TrayAppContext.cs', 'src\AppInfrastructure.cs',
    'src\MainForm.cs', 'src\CloseButtonOverlay.cs', 'src\DiagnosticsForm.cs',
    'src\TabScanner.cs', 'src\NativeMethods.cs', 'src\AppInfo.cs',
    'src\AssemblyInfo.cs', 'app.manifest', 'build.bat', 'Xtension.csproj',
    'README.md', 'VERSION.txt', 'DESIGN_LOG.md', 'publish-to-github.bat', '.github\workflows\ci.yml',
    '.github\workflows\release.yml'
)
foreach ($relative in $required) {
    $full = Join-Path $root $relative
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { throw "Required file missing: $relative" }
}
$sourceFiles = Get-ChildItem -LiteralPath (Join-Path $root 'src') -Filter '*.cs' -File
$sourceText = ($sourceFiles | ForEach-Object { Get-Content -LiteralPath $_.FullName -Raw }) -join "`n"
if ($sourceText -match 'BraveActiveCloseButton|Brave Active Tab') { throw 'Legacy product/namespace strings remain in C# source.' }
if ($sourceText -match 'MainForm\.AppVersion') { throw 'Stale MainForm.AppVersion reference remains.' }
if ($sourceText -notmatch 'AppInfo\.PollIntervalMilliseconds') { throw 'Poll interval is not centralized.' }
if ($sourceText -notmatch 'WalkSubtree') { throw 'Bounded recursive scanner implementation was not found.' }
$appInfo = Get-Content -LiteralPath (Join-Path $root 'src\AppInfo.cs') -Raw
if ($appInfo -notmatch 'Version\s*=\s*"0\.1\.0"') { throw 'AppInfo version is not 0.1.0.' }
$assemblyInfo = Get-Content -LiteralPath (Join-Path $root 'src\AssemblyInfo.cs') -Raw
if ($assemblyInfo -notmatch 'AssemblyVersion\("0\.1\.0\.0"\)' -or $assemblyInfo -notmatch 'AssemblyFileVersion\("0\.1\.0\.0"\)') { throw 'Assembly versions do not match v0.1.0.' }
$manifest = [xml](Get-Content -LiteralPath (Join-Path $root 'app.manifest') -Raw)
$project = [xml](Get-Content -LiteralPath (Join-Path $root 'Xtension.csproj') -Raw)
$manifestIdentity = $manifest.SelectSingleNode("/*[local-name()='assembly']/*[local-name()='assemblyIdentity']")
$projectRoot = $project.SelectSingleNode("/*[local-name()='Project']")
if (-not $manifestIdentity -or -not $projectRoot) { throw 'Invalid application manifest or MSBuild project XML.' }
if ($manifestIdentity.GetAttribute('name') -ne 'Xtension') { throw 'Manifest identity does not match Xtension.' }
$projectIncludes = @($project.SelectNodes("//*[local-name()='Compile']") | ForEach-Object { $_.GetAttribute('Include') })
foreach ($file in $sourceFiles) { if ($projectIncludes -notcontains ('src\' + $file.Name)) { throw "Project does not include $($file.Name)" } }
$releaseWorkflow = Get-Content -LiteralPath (Join-Path $root '.github\workflows\release.yml') -Raw
if ($releaseWorkflow -notmatch 'v\*' -or $releaseWorkflow -notmatch 'Xtension-win-x64\.exe' -or $releaseWorkflow -notmatch 'Xtension-win-x86\.exe') { throw 'Release workflow does not cover tag-triggered Windows x86/x64 assets.' }
Write-Host 'Xtension source consistency checks passed.' -ForegroundColor Green
Write-Host 'Version: v0.1.0'
Write-Host 'Coverage: Windows x86 + x64 build paths; Windows-only application.'
Write-Host 'Note: static validation does not replace compilation or runtime acceptance tests.' -ForegroundColor Yellow
